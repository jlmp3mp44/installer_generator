package org.example.server;

import java.io.*;
import java.net.*;
import java.sql.*;
import org.example.utils.DatabaseUtil;

public class Server {

  private static final int PORT = 8080;
  private static Connection connection;

  public static void main(String[] args) {
    try {
      // Initialize database connection
      initializeDatabase();

      // Start server socket
      ServerSocket serverSocket = new ServerSocket(PORT);
      System.out.println("Server started on port " + PORT);

      while (true) {
        Socket clientSocket = serverSocket.accept();
        System.out.println("New client connected: " + clientSocket.getInetAddress());

        // Handle client request in a new thread
        new ClientHandler(clientSocket).start();
      }
    } catch (IOException | SQLException e) {
      e.printStackTrace();
    }
  }

  private static void initializeDatabase() throws IOException, SQLException {
    connection = DatabaseUtil.getConnection();
    System.out.println("Database connected.");
  }


  static class ClientHandler extends Thread {
    private Socket socket;

    public ClientHandler(Socket socket) {
      this.socket = socket;
    }

    @Override
    public void run() {
      try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
          PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

        String request = in.readLine();
        System.out.println("Received request: " + request);

        // Process request
        String response = handleRequest(request);
        out.println(response);

      } catch (IOException e) {
        e.printStackTrace();
      } finally {
        try {
          socket.close();
        } catch (IOException e) {
          e.printStackTrace();
        }
      }
    }

    private String handleRequest(String request) {
      // Example: Parse and process request
      if (request.startsWith("REGISTER")) {
        String[] parts = request.split(" ");
        if (parts.length == 3) {
          return registerUser(parts[1], parts[2]);
        }
      }
      return "Invalid request";
    }

    private String registerUser(String username, String password) {
      try {
        String query = "INSERT INTO users (username, password) VALUES (?, ?)";
        PreparedStatement stmt = connection.prepareStatement(query);
        stmt.setString(1, username);
        stmt.setString(2, password);
        stmt.executeUpdate();
        return "User registered successfully";
      } catch (SQLException e) {
        return "Error: " + e.getMessage();
      }
    }
  }
}

