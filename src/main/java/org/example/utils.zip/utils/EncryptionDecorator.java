package org.example.utils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import org.example.converter.Converter;

public class EncryptionDecorator implements FileProcessor {
  private final FileProcessor wrapped;
  private final EncryptionStrategy strategy;
  private final Converter converter;

  public EncryptionDecorator(FileProcessor wrapped, EncryptionStrategy strategy, Converter converter) {
    this.wrapped = wrapped;
    this.strategy = strategy;
    this.converter =  converter;
  }

  @Override
  public void process(String inputFile, String outputFile, String key) throws Exception {
    // Створення тимчасового файлу

    converter.convert(inputFile, outputFile);

    System.out.println("Input file: " + inputFile);
    System.out.println("Temp file: " + outputFile);


    String customTempDir = "D:\\trpz_courcework\\installer_generator\\temp";
    File tempDir = new File(customTempDir);
    if (!tempDir.exists()) {
      tempDir.mkdirs(); // Створює директорію, якщо її не існує
    }

      File tempFilee = new File(tempDir, "temp_file.file");
      String tempFile = tempFilee.getAbsolutePath().toString();
      if (tempFilee.createNewFile()) {
        System.out.println("Temporary file created at: " + tempFilee.getAbsolutePath());
      } else {
        System.err.println("Failed to create temporary file.");
      }


    try {
      // Виконання обробки та шифрування
      System.out.println("Processing input file: " + inputFile + " to temporary file: " + tempFile);

      wrapped.process(inputFile, tempFile, key);
      System.out.println("Temporary file created: " + tempFile + " with size: " + new File(tempFile).length());
      File temp = new File(tempFile);
      if (!temp.exists() || temp.length() == 0) {
        throw new RuntimeException("Temporary file is missing or empty: " + tempFile);
      }

      strategy.encrypt(tempFile, outputFile, key);

      //new File(tempFile).delete();

    }
    catch (IOException e){
      System.out.println("rfrf");
    }
  }
}
