package org.example.processor;


public interface FileProcessor {
  String process() throws Exception;

}
