package org.example.converter;

public interface Converter {
  void convert(String inputFilePath, String outputFilePath);
}

