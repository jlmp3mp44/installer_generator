package org.example.encryption;


public interface FileProcessor {
  String process() throws Exception;

}
