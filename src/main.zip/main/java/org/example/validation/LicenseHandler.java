/*package org.example.validation;

package org.example.license;

public class LicenseHandler extends ValidationHandler {
  public static boolean isValidLicenseKey(String key) {
    // Простий приклад перевірки: перевірка довжини та префікса
    return key != null && key.startsWith("LICENSE-") && key.length() == 16;
  }
}*/

